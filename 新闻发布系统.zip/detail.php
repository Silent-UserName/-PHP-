<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>每日新闻</title>
  <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<!--  header  -->
<div class="nav-header">
  <div class="content">
    <div class="logo">每日新闻</div>
    <?php
    session_start();
    // 检查用户是否已登录
    if (isset($_SESSION['email'])) {
      // 用户已登录
      echo "<div class='login'>欢迎您，" . $_SESSION['email'] . "<a href='logout.php'>【退出登录】</a></div>";
    } elseif (isset($_COOKIE['email'])) {
      // 如果session中没有，检查cookie
      $_SESSION['email'] = $_COOKIE['email'];
      echo "<div class='login'>欢迎您，" . $_SESSION['email'] . "<a href='logout.php'>【退出登录】</a></div>";
    } else {
      echo "<a href='login.php'><div class='login'>注册/登录</div></a>";
    }
    ?>
  </div>
</div>
<!-- 导航栏 -->
<div class="nav">
  <div class="content">
    <ul>
      <li><a href="index.php" class="active"><span>每日新闻</span></a></li>
      <li style="float: right"><a href="admin.php"><span>新闻管理</span></a></li>
    </ul>

  </div>
</div>

<div class="main">
  <div class="content">
    <?php
    require './conn.php';

//    通过ID获取新闻详情
    if (!isset($_GET['id'])) {
      echo "<script>
      alert('错误请返回');
      history.back();
      </script>";
    } else {
      $id = $_GET['id'];
      $sql = "select * from news where id=$id";
      $result = mysqli_query($conn, $sql);
      if (!$result) {
        exit(mysqli_error($conn));
      }
      if (!mysqli_num_rows($result)) {
        echo "<script>
        alert('找不到信息,返回上一页');
        history.back();
      </script>";
      } else {
      $info = mysqli_fetch_assoc($result);
      }
    }
    ?>
    <div class="info-box">
      <div class="detail-title"><?= $info['title'] ?></div>
      <div class="detail-attr">
        <div class="attr">
          <span>发布时间：<?= $info['createtime'] ?></span>
        </div>
      </div>
      <div class="detail-con">
        <img src="<?= $info['image'] ?>" alt="">
        <div><?= $info['content'] ?></div>
      </div>
    </div>
    <div class="right-box">
      <div class="info-label">今日热门</div>
      <ul>
        <?php
//        获取hot=1的热门新闻
        $sql = "select id,title from news where hot=1";
        $result = mysqli_query($conn, $sql);
        if (!$result) {
          exit(mysqli_error($conn));
        }
        while ($info = mysqli_fetch_assoc($result)) {
          echo '<li>';
        echo '
        <div class="info">';
          echo '<a href="detail.php?id=' . $info['id'] . '" title="' . $info['title'] . '">' . $info['title'] . '</a>';
          echo '
        </div>
        ';
        echo '</li>';
        }
        ?>
      </ul>
    </div>
  </div>
</div>
<!--友情链接-->
<div class="footer">
  <div class="content">
    <div class="title">友情链接</div>
    <ul>
      <li><a href="http://www.baidu.com/" target="_blank">百度</a></li>
      <li><a href="http://www.qq.com/" target="_blank">腾讯</a></li>
      <li><a href="http://www.163.com/" target="_blank">网易</a></li>
    </ul>
  </div>
</div>
</body>
</html>