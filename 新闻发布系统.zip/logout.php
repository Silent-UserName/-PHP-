<?php
// 启动会话
session_start();
// 释放$_SESSION变量
session_unset();
// 销毁会话文件和释放会话ID
session_destroy();
// 删除cookie
if (isset($_COOKIE['email'])) {
  setcookie('email', '', time() - 3600); // 设置cookie过期时间为1小时前
}
// 用户已登出，跳转到首页
header("location:index.php");
?>