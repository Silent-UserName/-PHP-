/*
 Navicat Premium Data Transfer

 Source Server         : 本地连接
 Source Server Type    : MySQL
 Source Server Version : 50553
 Source Host           : localhost:3306
 Source Schema         : php_news

 Target Server Type    : MySQL
 Target Server Version : 50553
 File Encoding         : 65001

 Date: 22/12/2024 17:58:51
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for news
-- ----------------------------
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '标题',
  `image` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '图片',
  `hot` tinyint(1) NULL DEFAULT 0 COMMENT '是否热门 0否 1是',
  `content` longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '详情',
  `createtime` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `updatetime` datetime NULL DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '新闻表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of news
-- ----------------------------
INSERT INTO `news` VALUES (1, '南海热带低压生成 海南发布海上大风四级预警', 'images/upload/1734839317.jpeg', 1, '记者从海南省气象部门获悉，南海热带低压已于今天（22日）8时生成，其中心位于北纬7.1度、东经115.5度，也就是距离三沙市（西沙永兴岛）南偏东方向约1140公里的海面上，中心附近最大风力7级（15米/秒）。预计，该热带低压将以每小时20公里左右的速度向西北方向移动，逐渐趋向越南南部一带沿海，强度逐渐加强，并有可能加强为热带风暴级，于24日下半夜到25日白天在上述沿海地区登陆。\r\n\r\n　　海南省气象局2024年12月22日10时40分继续发布海上大风四级预警：受南海的热带低压和冷空气共同影响，22日下午到25日白天，南沙群岛附近海面，东北风7-8级，阵风9-10级；海南岛东部和南部海面，西沙、中沙群岛附近海面，东北风6-7级，阵风8-9级；琼州海峡，北部湾海面，本岛西部海面，东北风5-6级，阵风7-8级。', '2024-12-22 11:48:37', '2024-12-22 11:52:06');
INSERT INTO `news` VALUES (2, '老街区里潮流新丨古民居群焕新颜 和美乡村留乡愁', 'images/upload/1734839422.jpeg', 0, '央广网肥东12月21日消息（记者徐鹏）古民居的保护是传承中国传统文化，促进乡村人文生态可持续发展的重要一环，具有无可估量的价值。近年来，安徽大力推动传统村落保护利用，取得积极成效。截至目前，安徽累计认定省级以上传统村落807个，其中469个传统村落列入国家保护名录，数量位居全国第7。\r\n\r\n　　打造文旅IP、塑造文旅品牌、培育新型业态和消费模式，既是文旅融合赋能乡村振兴的新兴路径，也是推动乡村经济提质增效的有效手段。位于安徽省肥东县长临河镇的六家畈，地处巢湖之滨，是中国华侨国际文化交流基地，明清时期的古村落建筑群——六家畈古民居群坐落于此，是合肥市级文物保护单位。\r\n\r\n\r\n\r\n　　六家畈古民居群（肥东县委宣传部供图）\r\n\r\n　　“过去的六家畈是一个破旧的小村庄，许多古民居因年久失修而破败不堪。”当地村民介绍，从2019年开始，当地秉承尊重历史的原则，把破旧的古民居进行修缮，并保留它原有的风格。短短几年间，昔日破旧的村庄摇身一变成了侨乡文旅目的地。如今已建成畈塘民宿群、淮军文化陈列馆、玉兰故事馆、侨乡别院、1952·粮仓文创园等设施景点。\r\n\r\n　　六家畈在改造的过程中不仅保留了原有的建筑风貌，还挖掘独具特色的巢湖文化、淮军文化和侨乡文化内涵。玉兰故事馆因民居院中有两棵百年广玉兰树而得名，如今玉兰故事馆被改造为侨乡文化博物馆，里面不仅陈列着各种侨乡文化的展品，还有许多侨乡文创纪念品。\r\n\r\n\r\n\r\n　　六家畈古民居群（肥东县委宣传部供图）\r\n\r\n　　依托江淮侨乡古镇资源，近年来，肥东县以“江淮水镇、文化侨乡”为主题，打造了江淮侨乡六家畈项目，占地面积3908亩，一期投资5.5亿元，致力打造合肥乡村振兴新名片。\r\n\r\n　　此外，当地还将地方传统民俗、非遗工艺、特色美食等融入旅游，打造长临古街、撮街等特色街区，形成一批品质高端、业态新颖、特色鲜明的新业态新场景，其中环巢湖民宿，桂花台、观海、哈比、途居包公源等露营地，以及其他项目产品享誉省内外，为游客提供优质旅游体验。\r\n\r\n　　古村落是很多中国人的精神原乡，深藏着抹不掉的乡土记忆。\r\n\r\n　　记者了解到，作为传统村落资源大省，安徽积极推进传统村落保护利用法治化进程。去年，安徽省出台了《关于加强传统村落和传统建筑保护传承的指导意见》，明确提出加快立法步伐，制定省一级的传统村落保护传承利用法规。\r\n\r\n　　与此同时，安徽注重挖掘传统村落蕴含的历史、文化、艺术价值，适度有序发展传统村落旅游、休闲度假、文化创意、研学教育等产业，全省依托传统村落打造“微景区”近300处、乡村旅游重点村35个。', '2024-12-22 11:50:22', '2024-12-22 11:51:55');
INSERT INTO `news` VALUES (3, '冰雪运动解锁冬季新潮流！各地花式整活 冬游项目上新', 'images/upload/1734839496.jpeg', 1, '央视网消息：这个冬天冰雪运动潮流席卷各地，许多地方结合自身特色，上新冰雪活动和冬游项目，一起去看看。\r\n\r\n播放视频\r\n画中画\r\n\r\n　　冰雪运动进校园 助力冰雪运动蓬勃发展\r\n\r\n　　在黑龙江鹤岗市，当地深入学校，对1200余名学生开展冰雪运动知识讲座、冰雪器材展示以及现场体验等活动，让广大学生近距离感受冰雪运动的魅力。\r\n\r\n　　煤城小学六年级学生 王振军：教练很专业，教会了我很多滑雪技能，在这里我玩得很开心，同时也有许多小伙伴们陪着我一起玩。\r\n\r\n　　为了确保冰雪运动能够在校园中持续、深入地开展，鹤岗市松鹤滑雪场还为学校的体育老师们精心设计了专业培训课程。\r\n\r\n播放视频\r\n画中画\r\n\r\n　　冬游项目上新 丰富游客游玩体验\r\n\r\n　　位于洛阳栾川的伏牛山滑雪场开启了夜游模式。超过3公里的雪道上，游客在星光与灯光的交织中，感受夜间滑雪的别样浪漫。\r\n\r\n　　目前这里每天接待游客近2000人，较半月前增加25%。\r\n\r\n　　近日，在河南三门峡天鹅湖国家城市湿地公园内，上万只大天鹅来此越冬，也吸引了不少游客前来。目前这里平均每日接待游客超6000人次，相较两周前增加了20%，周末每日接待游客更是超2万人次。\r\n\r\n　　游客 许华阳：来看之后感觉确实非常震撼，那些天鹅都聚在湖面上，感觉非常好看。', '2024-12-22 11:51:36', '2024-12-22 11:52:00');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
