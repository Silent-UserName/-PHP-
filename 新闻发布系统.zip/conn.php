<?php
// 连接数据库
$db_host = 'localhost';
$db_user = 'root';
$db_password = '789987';
$db_name = 'news';

$conn = mysqli_connect($db_host, $db_user, $db_password, $db_name);
mysqli_set_charset($conn, 'utf8');
header('Content-Type:text/html;charset=UTF-8');
// 检查连接是否成功
if (!$conn) {
  die('数据库连接失败：' . mysqli_connect_error());
}
