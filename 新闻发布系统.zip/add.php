<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>每日新闻</title>
  <link href="css/style.css" rel="stylesheet" type="text/css">
  <link href="css/admin.css" rel="stylesheet" type="text/css">
</head>
<body>
<!--  header  -->
<div class="nav-header">
  <div class="content">
    <div class="logo">每日新闻</div>
    <?php
    session_start();
    // 检查用户是否已登录
    if (isset($_SESSION['email'])) {
      // 用户已登录
      echo "<div class='login'>欢迎您，" . $_SESSION['email'] . "<a href='logout.php'>【退出登录】</a></div>";
    } elseif (isset($_COOKIE['email'])) {
      // 如果session中没有，检查cookie
      $_SESSION['email'] = $_COOKIE['email'];
      echo "<div class='login'>欢迎您，" . $_SESSION['email'] . "<a href='logout.php'>【退出登录】</a></div>";
    } else {
      echo "<a href='login.php'><div class='login'>注册/登录</div></a>";
    }
    ?>
  </div>
</div>
<!-- 导航栏 -->
<div class="nav">
  <div class="content">
    <ul>
      <li><a href="index.php"><span>每日新闻</span></a></li>
      <li style="float: right"><a href="admin.php" class="active"><span>新闻管理</span></a></li>
    </ul>

  </div>
</div>

<div class="main">
  <div class="content">
    <div class="panel" style="padding: 20px 40px 60px;background: #fff;">
      <div id="info">
<!--        新增表单-->
        <form action="" method="post" enctype="multipart/form-data">
          <table>
            <tr>
              <td width=100>标题：</td>
              <td><input type="text" name="title" placeholder="请输入标题"></td>
            </tr>
            <tr>
              <td width=100>图片：</td>
              <td>
                <img class="edit-img" id="temp_img" src="" alt="">
                <input type="file" name="image" id="image">
              </td>
            </tr>
            <tr>
              <td width=100>热门：</td>
              <td>
                <input type="radio" name="hot" id="hot1" value="0" checked><label for="hot1">否</label>
                <input type="radio" name="hot" id="hot2" value="1"><label for="hot2">是</label>
              </td>
            </tr>
            <tr>
              <td width=100>详情：</td>
              <td><textarea name="content" rows="20" placeholder="请输入详情"></textarea></td>
            </tr>
            <tr>
              <td width=100></td>
              <td>
                <input type="submit" value="添加" name="submit" id="submit">
                <input type="button" value="返回" onclick="history.back()" class="btn-return">
              </td>
            </tr>
          </table>
        </form>
      </div>
    </div>
  </div>
</div>
<!--友情链接-->
<div class="footer">
  <div class="content">
    <div class="title">友情链接</div>
    <ul>
      <li><a href="http://www.baidu.com/" target="_blank">百度</a></li>
      <li><a href="http://www.qq.com/" target="_blank">腾讯</a></li>
      <li><a href="http://www.163.com/" target="_blank">网易</a></li>
    </ul>
  </div>
</div>
<?php
header("Content-type: text/html; charset=utf-8");
if (isset($_POST['submit'])) {
  include 'conn.php';
  //获取表单数据
  foreach ($_POST as $k => $v) {
    $$k = trim($v);
  }
  if ($title == '' || $content == '') {
    echo "<script>
            alert('标题不为空');
            history.back()
      </script>";
    exit;
  }
  $conn = mysqli_connect($db_host, $db_user, $db_password, $db_name);
  if (!$conn) {
    die('数据库连接失败：' . mysqli_connect_error());
  }
  //上传图片
  $upload = $_FILES['image'];
  if ($upload['error'] == 4) {          //没有文件
    $image = '';
  } elseif ($upload['error'] == 0) {         //文件上传成功
    $type = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!in_array($upload['type'], $type)) {
      echo "<script>
            alert('请上传正确的图片格式');
            history.back()
            </script>";
      exit();
    }
    if ($upload['size'] >= (1024 * 1024 * 2)) {
      echo "<script>
            alert('请上传2M以内的图片');
            history.back()
            </script>";
      exit();
    }
//    图片上传路径
    $save = 'images/upload/' . time() . '.' . substr($upload['type'],strpos($upload['type'], "/") + 1);
    if (!move_uploaded_file($upload['tmp_name'], $save)) {
      echo "<script>
            alert('上传失败，无法将文件保存到指定位置');
            history.back()
            </script>";
      exit();
    }
    $image = $save;
  } else {
    echo "<script>
            alert('文件上传失败');
            history.back()
      </script>";
  }
  //设置时区为东八区（北京时间）
  date_default_timezone_set('Asia/Shanghai');
  //设置发布时间和修改时间
  $createtime = $updatetime = date('Y-m-d H:i:s');
  //将表单信息写入数据
  $sql = "insert into news(title,content,hot,createtime,updatetime,image) 
    values('$title','$content','$hot','$createtime','$updatetime','$image')";
  $result = mysqli_query($conn, $sql);
  if ($result) {
    echo "<script>
                alert('添加成功');
                window.location.href = 'admin.php';
              </script>";
  } else {
    echo '<script>
                alert("添加失败' . mysqli_error($conn) . '");
              </script>';
  }
}
?>
<script src="js/jquery.js" type="text/javascript"></script>
<script src="js/time.js" type="text/javascript"></script>
<script>
  // 选择图片展示预览图
  $('#image').on('change', function () {
    if (this.files.length) {
      let file = this.files[0];
      let reader = new FileReader();
      //新建 FileReader 对象
      reader.onload = function () {
        // 当 FileReader 读取文件时候，读取的结果会放在 FileReader.result 属性中
        $('#temp_img').attr('src', this.result).show();
      };
      // 设置base64方式读取文件
      reader.readAsDataURL(file);
    } else {
      $('#temp_img').attr('src', '').hide();
    }
  })
</script>
</body>
</html>