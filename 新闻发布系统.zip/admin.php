<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>每日新闻</title>
  <link href="css/style.css" rel="stylesheet" type="text/css">
  <link href="css/admin.css" rel="stylesheet" type="text/css">
</head>
<body>
<!--  header  -->
<div class="nav-header">
  <div class="content">
    <div class="logo">每日新闻</div>
    <?php
    session_start();
    // 检查用户是否已登录
    if (isset($_SESSION['email'])) {
      // 用户已登录
      echo "<div class='login'>欢迎您，" . $_SESSION['email'] . "<a href='logout.php'>【退出登录】</a></div>";
    } elseif (isset($_COOKIE['email'])) {
      // 如果session中没有，检查cookie
      $_SESSION['email'] = $_COOKIE['email'];
      echo "<div class='login'>欢迎您，" . $_SESSION['email'] . "<a href='logout.php'>【退出登录】</a></div>";
    } else {
      echo "<a href='login.php'><div class='login'>注册/登录</div></a>";
    }
    ?>
  </div>
</div>
<!-- 导航栏 -->
<div class="nav">
  <div class="content">
    <ul>
      <li><a href="index.php"><span>每日新闻</span></a></li>
      <li style="float: right"><a href="admin.php" class="active"><span>新闻管理</span></a></li>
    </ul>

  </div>
</div>

<div class="main">
  <div class="content">
    <div class="panel" style="padding: 20px 40px 60px;background: #fff;">
      <div id="aricle">
        <form name="search" id='f1'>
          <input type="text" name="searchword" placeholder="输入关键词搜索" value="<?php if (isset($_GET['searchword'])) echo $_GET['searchword']; ?>">
          <input type="submit" value="搜索">
        </form>
        <input type="button" value="新增" id="add" onclick="location.href='add.php'">
        <table id='t1'>
          <tr>
            <th>编号</th>
            <th>标题</th>
            <th>图片</th>
            <th>热门</th>
            <th>创建时间</th>
            <th>修改时间</th>
            <th>操作</th>
          </tr>
          <?php
          require './conn.php';
//          获取URL中的搜索词
          if (isset($_GET['searchword'])) {
            $searchword = $_GET['searchword'];
            $url = "admin.php?searchword={$searchword}&";
          } else {
            $searchword = '';
            $url = 'admin.php?';
          }
          $page = isset($_GET['page']) ? $_GET['page'] : 1;
          $size = 10;
          $sql = "select * from news where title like '%$searchword%'";
          $result = mysqli_query($conn, $sql);
          $total = mysqli_num_rows($result);
          $sql = "select * from news where title like '%$searchword%' order by id limit " . ($page - 1) * $size . ",$size";
          $result = mysqli_query($conn, $sql);
          if (!$result) {
            exit(mysqli_error($conn));
          }
//          列表
          while ($info = mysqli_fetch_assoc($result)) {
            echo '<tr>';
            echo '<td>' . $info['id'] . '</td>';
            echo "<td style='max-width: 200px'><a href='detail.php?id=" . $info['id'] . "'>" . $info['title'] . "</a></td>";
            echo "<td><img height=80 src='" . $info['image'] . "'></td>";
            echo '<td>' . ($info['hot'] == 1 ? '是' : '否') . '</td>';
            echo '<td>' . $info['createtime'] . '</td>';
            echo '<td>' . $info['updatetime'] . '</td>';
            echo "<td><a href='edit.php?id=" . $info['id'] . "'>修改</a>/<a href='del.php?id=" . $info['id'] . "'>删除</a></td>";
            echo '</tr>';
          }
          ?>

        </table>
      </div>
      <div id='page'>
        <?= page_html($url, $page, $total, $size) ?>
      </div>
    </div>
  </div>
</div>
<!--友情链接-->
<div class="footer">
  <div class="content">
    <div class="title">友情链接</div>
    <ul>
      <li><a href="http://www.baidu.com/" target="_blank">百度</a></li>
      <li><a href="http://www.qq.com/" target="_blank">腾讯</a></li>
      <li><a href="http://www.163.com/" target="_blank">网易</a></li>
    </ul>
  </div>
</div>
<?php
function page_html($url,$page,$total,$size){
  $maxpage = ceil($total / $size) ;
//  if($maxpage < 9){
//    return '';
//  }
  if($page == 1){
    $first = '首页';
    $prev = '上一页';
  }else{
    $first = '<a href="'. $url .'">首页</a>';
    $prev = '<a href="'. $url .'page='. ($page-1) .'">上一页</a>';
  }
  if($page == $maxpage){
    $next = '下一页';
    $last = '尾页';
  }else{
    $next ='<a href="'. $url .'page='. ($page+1) .'">下一页</a>';
    $last ='<a href="'. $url .'page='. $maxpage .'">尾页</a>';
  }
  return "<p>当前位于 $page / $maxpage 页</p><p>$first $prev $next $last</p>";
}
?>
</body>
</html>