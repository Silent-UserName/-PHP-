<?php
    header('Content-Type:text/html;charset=UTF-8');
    require './conn.php';
//    从url获取要删除的文章id
    $id = isset($_GET['id']) ? $_GET['id'] : '';
    if(!isset($_GET['yorn'])){
        echo"
                <script>
                    location.href='del.php?id=$id&yorn='+confirm('确定删除该文章吗？');
                </script>
            ";
            exit();
    }
    if($_GET['yorn'] == 'false'){
        header('Location:admin.php');
        exit();
    }
    //删除数据库信息
    $sql="select * from news where id='$id'";
    $result = mysqli_query($conn,$sql);
    if(!$result){
        exit(mysqli_error($conn));
    }
    $info = mysqli_fetch_assoc($result);
    $img = $info['image'];
    $sql = "delete from news where id = '$id'";
    $result = mysqli_query($conn,$sql);
//    删除对应的图片
    if($result) {
        if(file_exists($img)){//根据路径判断文件是否存在
            unlink($img);//通过路径删除源文件
        }
        echo '<script>
            alert("删除成功");
            location.href="admin.php";
        </script>';
        } else {
        echo '<script>
            alert("删除失败'.mysqli_error($conn).'");
            location.href="admin.php";
        </script>';
    }
    ?>