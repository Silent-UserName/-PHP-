<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>每日新闻</title>
    <link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<body>
<!--  header  -->
<div class="nav-header">
    <div class="content">
        <div class="logo">每日新闻</div>
    </div>
</div>
<!-- 导航栏 -->
<div class="nav">
    <div class="content">
        <ul>
          <li><a href="index.php"><span>每日新闻</span></a></li>
        </ul>
    </div>
</div>

<div class="main">
    <div class="content" style="padding-top: 20px">
        <!-- 左侧图片 -->
        <img src="images/login.jpeg" alt="" style="width: 800px;float: left">
        <!-- 右侧表单 -->
        <div class="login-box">
            <div class="tab">
                <button class="tab-links active" onclick="openTab(event, 'Login')">登录</button>
                <button class="tab-links" onclick="openTab(event, 'Register')">注册</button>
            </div>
            <!-- 登录表单 -->
            <form id="Login" class="tab-content" style="display: block;" method="post" action="">
                <input type="email" name="login_email" placeholder="请输入邮箱，例：123@qq.com">
                <input type="password" name="login_password" placeholder="输入密码，包含数字、字母大小写，8-10个字符">
                <input type="submit" class="btn-login" value="登录" name="login">
            </form>
            <!-- 注册表单 -->
            <form id="Register" class="tab-content" method="post" action="">
                <input type="email" name="reg_email" placeholder="请输入邮箱，例：123@qq.com">
                <input type="password" name="reg_password" placeholder="输入密码，包含数字、字母大小写，8-10个字符">
                <input type="submit" class="btn-login" value="注册" name="register">
            </form>
        </div>
    </div>
</div>
<!--友情链接-->
<div class="footer">
    <div class="content">
        <div class="title">友情链接</div>
        <ul>
            <li><a href="http://www.baidu.com/" target="_blank">百度</a></li>
            <li><a href="http://www.qq.com/" target="_blank">腾讯</a></li>
            <li><a href="http://www.163.com/" target="_blank">网易</a></li>
        </ul>
    </div>
</div>

<?php
require './conn.php';
if (isset($_POST['register'])) {
  // 注册
  if (!empty($_POST['reg_email']) && !empty($_POST['reg_password'])) {
    if(!preg_match('/^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/',$_POST['reg_email'])){
      echo "<script>
                alert('请输入正确格式的邮箱');
                </script>";
      exit;
    }
    if(!preg_match('/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[a-zA-Z0-9]{8,10}$/',$_POST['reg_password'])){
      echo "<script>
                alert('请输入正确格式的密码');
                </script>";
      exit;
    }
    $email = $_POST['reg_email'];
    $password = md5($_POST['reg_password']); // md5加密密码
    $sql = "SELECT * from user WHERE email='$email'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) == 0) {
      $sql = "INSERT INTO user (email, password) VALUES ('$email', '$password')";
      if (mysqli_query($conn, $sql)) {
        echo '<script>
                    alert("注册成功");
                    window.location.href = "login.php";
                    </script>';
        // 关闭数据库连接
        mysqli_close($conn);
      } else {
        echo '<script>
                    alert("注册失败");
                    </script>';
      }
    } else {
      echo '<script>
                alert("该邮箱已被注册");
                </script>';
    }
  } else {
    echo '<script>
            alert("请输入完整的注册信息");
            </script>';
  }
} else if (isset($_POST['login'])) {
  // 登录
  if (!empty($_POST['login_email']) && !empty($_POST['login_password'])) {
    if(!preg_match('/^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/',$_POST['login_email'])){
      echo "<script>
                alert('请输入正确格式的邮箱');
                </script>";
      exit;
    }
    if(!preg_match('/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[a-zA-Z0-9]{8,10}$/',$_POST['login_password'])){
      echo "<script>
                alert('请输入正确格式的密码');
                </script>";
      exit;
    }
    $email = $_POST['login_email'];
    $password = md5($_POST['login_password']); // md5加密密码
    $sql = "SELECT * from user WHERE email='$email' AND password='$password'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) == 1) {
      $row = mysqli_fetch_assoc($result);
      $_SESSION['email'] = $row['email'];
      // 设置一个7天后过期的cookie
      setcookie('email', $row['email'], time() + (7 * 24 * 60 * 60));
      // 关闭数据库连接
      mysqli_close($conn);
      echo '<script>
                alert("登录成功");
                window.location.href = "index.php";
                </script>';
    } else {
      echo '<script>
                alert("用户名或密码错误");
                </script>';
    }
  } else {
    echo '<script>
            alert("请输入用户名和密码");
            </script>';
  }
}
?>
<script type="text/javascript">
  // 登录/注册标签切换
  function openTab(evt, tabName) {
    var i, tabcontent, tablinks;
    // 获取所有class为tab-content的表单元素
    tabcontent = document.getElementsByClassName("tab-content");
    // 遍历元素，display样式全部设为none，隐藏
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    // 通过id获取当前点击标签对应的form表单，display样式设为block，显示
    document.getElementById(tabName).style.display = "block";

    // 获取所有class为tab-links的标签元素
    tablinks = document.getElementsByClassName("tab-links");
    // 遍历元素，class全部移除active，对应的样式为字体缩小，没有底部边框
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].classList.remove("active");
    }
    // 当前点击的标签class添加active，对应的样式为字体变大，增加蓝色底部边框
    evt.currentTarget.classList.add("active");
  }

</script>
</body>
</html>